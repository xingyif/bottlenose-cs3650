javac -cp grading:/Library/JUNIT/junit-4.12.jar:/Library/JUNIT/hamcrest-core-1.3.jar grading/*.java
java -cp grading:/Library/JUNIT/junit-4.12.jar:/Library/JUNIT/hamcrest-core-1.3.jar org.junit.runner.JUnitCore Grade03resubmit
