javac -cp .:lib/assets/* ./*.java
javac -cp .:lib/assets/* org/cs3500/*.java
java -cp .:lib/assets/* org.cs3500.TAPRunner Grade03resubmit
