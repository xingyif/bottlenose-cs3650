javac -cp grading:/Library/JUNIT/junit-4.12.jar:/Library/JUNIT/hamcrest-core-1.3.jar grading/*.java
javac -cp grading:/Library/JUNIT/junit-4.12.jar:/Library/JUNIT/hamcrest-core-1.3.jar grading/org/cs3500/*.java
java -cp grading:/Library/JUNIT/junit-4.12.jar:/Library/JUNIT/hamcrest-core-1.3.jar org.cs3500.TAPRunner Grade03resubmit

# javac -cp .:../../lib/assets/* ./*.java
# javac -cp .:../../lib/assets/* org/cs3500/*.java
# java -cp .:../../lib/assets/* org.cs3500.TAPRunner Grade03resubmit
